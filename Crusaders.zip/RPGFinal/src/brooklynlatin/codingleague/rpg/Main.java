package brooklynlatin.codingleague.rpg;

import brooklynlatin.codingleague.rpg.engine.Game;
import brooklynlatin.codingleague.rpg.engine.RPGGame;

public class Main
{
	private static Main _instance;
	
	public static void main(String[] args)
	{
		_instance = new Main();
	}
	
	public Main()
	{
		_instance = this;
		Game game = new RPGGame();
		game.start();
	}
	
	public static Main getInstance()
	{
		if (_instance == null)
		{
			new Main();
		}
		
		return _instance;
	}
}