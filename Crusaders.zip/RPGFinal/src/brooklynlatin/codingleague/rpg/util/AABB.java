package brooklynlatin.codingleague.rpg.util;

import brooklynlatin.codingleague.rpg.entity.Entity;
import brooklynlatin.codingleague.rpg.graphics.math.Vector2f;

/**
 * This class represents an axis-aligned bounding box.
 */
public class AABB
{
	public Vector2f Min, Max;

	public AABB(Entity entity)
	{
		Min = new Vector2f(entity.getX(), entity.getY());
		Max = new Vector2f(
				entity.getX() + entity.getWidth(),
				entity.getY() + entity.getHeight()
				);
	}

	/**
	 * Checks if this AABB intersects another AABB.
	 *
	 * @param other The other AABB
	 *
	 * @return true if a collision was detected.
	 */
	public boolean intersects(AABB other)
	{
		if (Max.X < other.Min.X)
		{
			return false;
		}

		if (Max.Y < other.Min.Y)
		{
			return false;
		}

		if (Min.X > other.Max.X)
		{
			return false;
		}

		if (Min.Y > other.Max.Y)
		{
			return false;
		}

		// All tests failed, we have a intersection
		return true;
	}
}