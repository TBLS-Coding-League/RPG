package brooklynlatin.codingleague.rpg.engine;

import static org.lwjgl.glfw.GLFW.glfwInit;
import static org.lwjgl.glfw.GLFW.glfwSetErrorCallback;
import static org.lwjgl.glfw.GLFW.glfwTerminate;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;

import brooklynlatin.codingleague.rpg.engine.state.GameState;
import brooklynlatin.codingleague.rpg.engine.state.StateMachine;
import brooklynlatin.codingleague.rpg.graphics.Renderer;
import brooklynlatin.codingleague.rpg.graphics.Window;

/**
 * The game class just initializes the game and starts the game loop. After
 * ending the loop it will get disposed.
 */
public abstract class Game
{
	public static final int TARGET_FPS = 75;
	public static final int TARGET_UPS = 30;

	/**
	 * The error callback for GLFW.
	 */
	private GLFWErrorCallback _errorCallback;

	/**
	 * Shows if the game is running.
	 */
	protected boolean Running;

	/**
	 * The GLFW window used by the game.
	 */
	protected Window Window;
	/**
	 * Used for timing calculations.
	 */
	protected Timer Timer;
	/**
	 * Used for rendering.
	 */
	protected Renderer Renderer;
	/**
	 * Stores the current state.
	 */
	protected StateMachine State;

	/**
	 * Default contructor for the game.
	 */
	public Game()
	{
		Timer = new Timer();
		Renderer = new Renderer();
		State = new StateMachine();
	}

	/**
	 * This should be called to initialize and start the game.
	 */
	public void start()
	{
		init();
		gameLoop();
		dispose();
	}

	/**
	 * Releases resources that where used by the game.
	 */
	public void dispose()
	{
		/* Dipose renderer */
		Renderer.dispose();

		/* Set empty state to trigger the exit method in the current state */
		State.change(null);

		/* Release window and its callbacks */
		Window.destroy();

		/* Terminate GLFW and release the error callback */
		glfwTerminate();
		_errorCallback.free();
	}

	/**
	 * Initializes the game.
	 */
	public void init()
	{
		/* Set error callback */
		_errorCallback = GLFWErrorCallback.createPrint();
		glfwSetErrorCallback(_errorCallback);

		/* Initialize GLFW */
		if (!glfwInit())
		{
			throw new IllegalStateException("Unable to initialize GLFW!");
		}

		/* Create GLFW window */
		Window = new Window(1000, 480, "Crusaders", true);

		/* Initialize timer */
		Timer.init();

		/* Initialize renderer */
		Renderer.init();

		/* Initialize states */
		initStates();

		/* Initializing done, set running to true */
		Running = true;
	}

	/**
	 * Initializes the states.
	 */
	public void initStates()
	{
		State.add("game", new GameState(Renderer));
		State.change("game");
	}

	/**
	 * The game loop. <br>
	 * For implementation take a look at <code>VariableDeltaGame</code> and
	 * <code>FixedTimestepGame</code>.
	 */
	public abstract void gameLoop();

	/**
	 * Handles input.
	 */
	public void input()
	{
		State.input();
	}

	/**
	 * Updates the game.
	 */
	public void update()
	{
		State.update();
	}

	/**
	 * Renders the game (no interpolation).
	 */
	public void render()
	{
		State.render();
	}

	/**
	 * Renders the game (with interpolation).
	 *
	 * @param alpha Alpha value, needed for interpolation
	 */
	public void render(float alpha)
	{
		State.render(alpha);
	}

	/**
	 * Synchronizes the game at specified frames per second.
	 *
	 * @param fps Frames per second
	 */
	public void sync(int fps)
	{
		double lastLoopTime = Timer.getLastLoopTime();
		double now = Timer.getTime();
		float targetTime = 1f / fps;

		while (now - lastLoopTime < targetTime)
		{
			Thread.yield();

			/* This is optional if you want your game to stop consuming too much
			 * CPU but you will lose some accuracy because Thread.sleep(1)
			 * could sleep longer than 1 millisecond */
			try
			{
				Thread.sleep(1);
			}
			catch (InterruptedException ex)
			{
				Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
			}

			now = Timer.getTime();
		}
	}

	/**
	 * Determines if the OpenGL context supports version 3.2.
	 *
	 * @return true, if OpenGL context supports version 3.2, else false
	 */
	public static boolean isDefaultContext()
	{
		return GL.getCapabilities().OpenGL32;
	}
}