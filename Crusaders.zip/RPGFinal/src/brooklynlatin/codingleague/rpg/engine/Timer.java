package brooklynlatin.codingleague.rpg.engine;

import static org.lwjgl.glfw.GLFW.glfwGetTime;

/**
 * The timer class is used for calculating delta time and also FPS and UPS
 * calculation.
 */
public class Timer
{
	/**
	 * System time since last loop.
	 */
	private double _lastLoopTime;
	/**
	 * Used for FPS and UPS calculation.
	 */
	private float _timeCount;
	/**
	 * Frames per second.
	 */
	private int _fps;
	/**
	 * Counter for the FPS calculation.
	 */
	private int _fpsCount;
	/**
	 * Updates per second.
	 */
	private int _ups;
	/**
	 * Counter for the UPS calculation.
	 */
	private int _upsCount;

	/**
	 * Initializes the timer.
	 */
	public void init()
	{
		_lastLoopTime = getTime();
	}

	/**
	 * Returns the time elapsed since <code>glfwInit()</code> in seconds.
	 *
	 * @return System time in seconds
	 */
	public double getTime()
	{
		return glfwGetTime();
	}

	/**
	 * Returns the time that have passed since the last loop.
	 *
	 * @return Delta time in seconds
	 */
	public float getDelta()
	{
		double time = getTime();
		float delta = (float) (time - _lastLoopTime);
		_lastLoopTime = time;
		_timeCount += delta;
		return delta;
	}

	/**
	 * Updates the FPS counter.
	 */
	public void updateFPS()
	{
		_fpsCount++;
	}

	/**
	 * Updates the UPS counter.
	 */
	public void updateUPS()
	{
		_upsCount++;
	}

	/**
	 * Updates FPS and UPS if a whole second has passed.
	 */
	public void update()
	{
		if (_timeCount > 1f)
		{
			_fps = _fpsCount;
			_fpsCount = 0;

			_ups = _upsCount;
			_upsCount = 0;

			_timeCount -= 1f;
		}
	}

	/**
	 * Getter for the FPS.
	 *
	 * @return Frames per second
	 */
	public int getFPS()
	{
		return _fps > 0 ? _fps : _fpsCount;
	}

	/**
	 * Getter for the UPS.
	 *
	 * @return Updates per second
	 */
	public int getUPS()
	{
		return _ups > 0 ? _ups : _upsCount;
	}

	/**
	 * Getter for the last loop time.
	 *
	 * @return System time of the last loop
	 */
	public double getLastLoopTime()
	{
		return _lastLoopTime;
	}
}