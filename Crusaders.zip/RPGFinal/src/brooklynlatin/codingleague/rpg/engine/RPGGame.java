package brooklynlatin.codingleague.rpg.engine;

import static org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_CONTROL;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_CONTROL;
import static org.lwjgl.glfw.GLFW.GLFW_PRESS;
import static org.lwjgl.glfw.GLFW.glfwGetKey;

import org.lwjgl.glfw.GLFW;

/**
 * This class contains the implementation for a fixed timestep RPG game loop.
 */
public class RPGGame extends Game
{
	@Override
	public void gameLoop()
	{
		float delta;
		float accumulator = 0f;
		float interval = 1f / TARGET_UPS;
		float alpha;

		while (Running)
		{
			/* Check if game should close */
			if (Window.isClosing())
			{
				Running = false;
			}

			/* Get delta time and update the accumulator */
			delta = Timer.getDelta();
			accumulator += delta;

			/* Handle input */
			input();

			/* Update game and timer UPS if enough time has passed */
			while (accumulator >= interval)
			{
				update();
				Timer.updateUPS();
				accumulator -= interval;
			}

			/* Calculate alpha value for interpolation */
			alpha = accumulator / interval;

			/* Render game and update timer FPS */
			render(alpha);
			Timer.updateFPS();

			/* Update timer */
			Timer.update();
			
			if (glfwGetKey(GLFW.glfwGetCurrentContext(), GLFW_KEY_RIGHT_CONTROL) == GLFW_PRESS || glfwGetKey(GLFW.glfwGetCurrentContext(), GLFW_KEY_LEFT_CONTROL) == GLFW_PRESS)
			{
				/* Draw FPS, UPS and Context version */
				int height = Renderer.getDebugTextHeight("Context");
				Renderer.drawDebugText("FPS: " + Timer.getFPS() + " | UPS: " + Timer.getUPS(), 5, 5 + height);
				Renderer.drawDebugText("Context: " + (Game.isDefaultContext() ? "3.2 core" : "2.1"), 5, 5);
			}

			/* Update window to show the new screen */
			Window.update();

			/* Synchronize if v-sync is disabled */
			if (!Window.isVSyncEnabled())
			{
				sync(TARGET_FPS);
			}
		}
	}
}