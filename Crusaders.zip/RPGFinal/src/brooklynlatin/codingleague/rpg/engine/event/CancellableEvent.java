package brooklynlatin.codingleague.rpg.engine.event;

public abstract class CancellableEvent extends GameEvent
{
	private boolean _cancelled = false;
	
	public boolean isCancelled()
	{
		return _cancelled;
	}
	
	public void setCancelled(boolean cancelled)
	{
		_cancelled = cancelled;
	}
}