package brooklynlatin.codingleague.rpg.engine.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EventEngine
{
	private static Map<Class<? extends GameEvent>, List<EventListener<?>>> _listeners = new HashMap<>();
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T extends GameEvent> T callEvent(T event)
	{
		if (!_listeners.containsKey(event.getClass()))
		{
			return event;
		}
		for (EventListener listener : _listeners.get(event.getClass()))
		{
			listener.handleEvent(event);
		}
		return event;
	}
	
	public static void registerListener(EventListener<?> listener)
	{
		if (!_listeners.containsKey(listener.getEventClass()))
		{
			_listeners.put(listener.getEventClass(), new ArrayList<>());
		}
		_listeners.get(listener.getEventClass()).add(listener);
		_listeners.get(listener.getEventClass()).sort((o1, o2) ->
		{
			return Integer.valueOf(o1.getPriority().ordinal()).compareTo(Integer.valueOf(o2.getPriority().ordinal()));
		});
	}
}