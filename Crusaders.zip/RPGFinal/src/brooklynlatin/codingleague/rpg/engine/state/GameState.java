package brooklynlatin.codingleague.rpg.engine.state;

import static org.lwjgl.opengl.GL11.glClearColor;

import java.nio.IntBuffer;
import java.util.Random;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.system.MemoryStack;

import brooklynlatin.codingleague.rpg.entity.EntityEngine;
import brooklynlatin.codingleague.rpg.entity.entities.EnemyCharacter;
import brooklynlatin.codingleague.rpg.entity.entities.PlayerCharacter;
import brooklynlatin.codingleague.rpg.graphics.Color;
import brooklynlatin.codingleague.rpg.graphics.Renderer;
import brooklynlatin.codingleague.rpg.graphics.Texture;

/**
 * This class contains a simple game.
 */
public class GameState implements State
{
	public static final int NO_COLLISION = 0;
	public static final int COLLISION_TOP = 1;
	public static final int COLLISION_BOTTOM = 2;
	public static final int COLLISION_RIGHT = 3;
	public static final int COLLISION_LEFT = 4;

	private Texture _texture;
	private final Renderer _renderer;

	private EntityEngine _entityEngine;
	private PlayerCharacter _player;
	
	private int _score;
	private int _gameWidth;
	private int _gameHeight;
	
	private long _lastEnemy;
	
	private Random _rng = new Random();
	
	private boolean _playerDead = false;

	public GameState(Renderer renderer)
	{
		_renderer = renderer;
	}

	@Override
	public void input()
	{
		if (_playerDead)
		{
			return;
		}
		_entityEngine.input();
	}

	@Override
	public void update(float delta)
	{
		if (_playerDead)
		{
			return;
		}
		if (_player.isRemoved())
		{
			_playerDead = true;
			return;
		}
		/* Update position */
		_entityEngine.update(delta);

		/* Check for collisions */
		_entityEngine.checkBorderCollisions(_gameHeight, _gameWidth);
		
		if (System.currentTimeMillis() >= (_lastEnemy + 10000))
		{
			_lastEnemy = System.currentTimeMillis();
			_entityEngine.createEntity(EnemyCharacter.class, _player.getX() + (10 + (_rng.nextInt(50) - 10)), _player.getY() + (10 + (_rng.nextInt(50) - 10)), _texture);
			_score += 50;
		}
	}

	@Override
	public void render(float alpha)
	{
		/* Clear drawing area */
		_renderer.clear();
		
		if (_playerDead)
		{
			String loseText = "You Lose!";
			int loseTextWidth = _renderer.getTextWidth(loseText);
			int loseTextHeight = _renderer.getTextHeight(loseText);
			float loseTextX = (_gameWidth - loseTextWidth) / 2f;
			float loseTextY = _gameHeight - loseTextHeight - 5;
			_renderer.drawText(loseText, loseTextX, loseTextY, Color.BLACK);
			return;
		}

		/* Draw game objects */
		_texture.bind();
		_renderer.begin();
		_entityEngine.render(_renderer, alpha);
		_renderer.end();

		/* Draw stats */
		String statsText = "Stats";
		int statsTextWidth = _renderer.getTextWidth(statsText);
		int statsTextHeight = _renderer.getTextHeight(statsText);
		float statsTextX = (_gameWidth - statsTextWidth) / 2f;
		float statsTextY = _gameHeight - statsTextHeight - 5;
		_renderer.drawText(statsText, statsTextX, statsTextY, Color.BLACK);

		String healthText = "Health | " + _player.getHealth();
		int healthTextWidth = _renderer.getTextWidth(healthText);
		int healthTextHeight = _renderer.getTextHeight(healthText);
		float healthTextX = _gameWidth / 2f - healthTextWidth - 50;
		float healthTextY = statsTextY - healthTextHeight;
		_renderer.drawText(healthText, healthTextX, healthTextY, Color.BLACK);

		String scoreText = _score + " | Score";
		//int scoreTextWidth = _renderer.getDebugTextWidth(scoreText);
		int scoreTextHeight = _renderer.getTextHeight(scoreText);
		float scoreTextX = _gameWidth / 2f + 50;
		float scoreTextY = statsTextY - scoreTextHeight;
		_renderer.drawText(scoreText, scoreTextX, scoreTextY, Color.BLACK);
	}

	@Override
	public void enter()
	{
		/* Get width and height of framebuffer */
		int width, height;
		try (MemoryStack stack = MemoryStack.stackPush())
		{
			long window = GLFW.glfwGetCurrentContext();
			IntBuffer widthBuffer = stack.mallocInt(1);
			IntBuffer heightBuffer = stack.mallocInt(1);
			GLFW.glfwGetFramebufferSize(window, widthBuffer, heightBuffer);
			width = widthBuffer.get();
			height = heightBuffer.get();
		}

		/* Load texture */
		_texture = Texture.loadTexture("resources/Character.png");

		/* Initialize game objects */
		_entityEngine = new EntityEngine();
		_player = _entityEngine.createEntity(PlayerCharacter.class, width - (width / 2f), height - (height / 2f) - 50, _texture);

		/* Initialize variables */
		_gameWidth = width;
		_gameHeight = height;
		
		_lastEnemy = System.currentTimeMillis();

		glClearColor(0.7f, 0.7f, 0f, 1f);
	}

	@Override
	public void exit()
	{
		_texture.delete();
	}
}