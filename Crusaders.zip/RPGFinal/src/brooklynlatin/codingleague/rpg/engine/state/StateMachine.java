package brooklynlatin.codingleague.rpg.engine.state;

import java.util.HashMap;
import java.util.Map;

/**
 * The state machine handles different states and can be a state itself.
 */
public class StateMachine implements State
{
	/**
	 * Contains all states of this state machine.
	 */
	private final Map<String, State> _states;
	/**
	 * Current active state.
	 */
	private State _currentState;

	/**
	 * Creates a state machine.
	 */
	public StateMachine()
	{
		_states = new HashMap<>();
		_currentState = new EmptyState();
		_states.put(null, _currentState);
	}

	/**
	 * Adds a state with specified name.
	 *
	 * @param name  Name of the state
	 * @param state The state to add
	 */
	public void add(String name, State state)
	{
		_states.put(name, state);
	}

	/**
	 * Changes the current state.
	 *
	 * @param name Name of the desired state
	 */
	public void change(String name)
	{
		_currentState.exit();
		_currentState = _states.get(name);
		_currentState.enter();
	}

	@Override
	public void input()
	{
		_currentState.input();
	}

	@Override
	public void update()
	{
		_currentState.update();
	}

	@Override
	public void update(float delta)
	{
		_currentState.update(delta);
	}

	@Override
	public void render()
	{
		_currentState.render();
	}

	@Override
	public void render(float alpha)
	{
		_currentState.render(alpha);
	}

	@Override
	public void enter()
	{
		_currentState.enter();
	}

	@Override
	public void exit()
	{
		_currentState.exit();
	}
}