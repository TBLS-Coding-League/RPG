package brooklynlatin.codingleague.rpg.engine.state;

/**
 * The empty state does nothing. Really.
 */
public class EmptyState implements State
{
	@Override
	public void input() {}

	@Override
	public void update(float delta) {}

	@Override
	public void render(float alpha) {}

	@Override
	public void enter() {}

	@Override
	public void exit() {}
}