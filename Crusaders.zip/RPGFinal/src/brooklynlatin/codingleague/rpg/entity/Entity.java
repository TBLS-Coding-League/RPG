package brooklynlatin.codingleague.rpg.entity;

import static brooklynlatin.codingleague.rpg.engine.state.GameState.COLLISION_BOTTOM;
import static brooklynlatin.codingleague.rpg.engine.state.GameState.COLLISION_LEFT;
import static brooklynlatin.codingleague.rpg.engine.state.GameState.COLLISION_RIGHT;
import static brooklynlatin.codingleague.rpg.engine.state.GameState.COLLISION_TOP;
import static brooklynlatin.codingleague.rpg.engine.state.GameState.NO_COLLISION;

import brooklynlatin.codingleague.rpg.graphics.Color;
import brooklynlatin.codingleague.rpg.graphics.Renderer;
import brooklynlatin.codingleague.rpg.graphics.Texture;
import brooklynlatin.codingleague.rpg.graphics.math.Vector2f;
import brooklynlatin.codingleague.rpg.util.AABB;

public abstract class Entity
{
	protected EntityEngine Engine;
	private final int _id;
	private String _name;
	private boolean _removing;
	private boolean _removed;

	protected Vector2f PreviousPosition;
	protected Vector2f Position;

	protected final AABB Aabb;

	protected final float Speed;
	protected Vector2f Direction;

	protected final Color Color;
	protected final Texture Texture;

	protected final int Width;
	protected final int Height;

	protected final int Tx;
	protected final int Ty;

	public Entity(EntityEngine engine, int id, String name, Color color, Texture texture, float x, float y, float speed, int width, int height, int tx, int ty)
	{
		Engine = engine;
		_id = id;
		_name = name;

		PreviousPosition = new Vector2f(x, y);
		Position = new Vector2f(x, y);
		
		Direction = new Vector2f();

		Aabb = new AABB(this);

		Color = color;
		Texture = texture;

		Speed = speed;
		Width = width;
		Height = height;
		Tx = tx;
		Ty = ty;

		onSpawn();
	}

	protected abstract void onSpawn();
	protected abstract void updateCustom();
	protected abstract void onRemove();

	public int getId()
	{
		return _id;
	}

	public String getName()
	{
		return _name;
	}

	public boolean isRemoved()
	{
		return _removed;
	}

	public float getX()
	{
		return Position.X;
	}

	public float getY()
	{
		return Position.Y;
	}

	public float getWidth()
	{
		return Width;
	}

	public float getHeight()
	{
		return Height;
	}

	public AABB getAABB()
	{
		return Aabb;
	}

	public void remove()
	{
		if (_removed)
		{
			return;
		}
		_removing = true;
	}

	protected void update(float delta)
	{
		if (_removing)
		{
			_removed = true;
			onRemove();
			return;
		}
		updateCustom();
		PreviousPosition = new Vector2f(Position.X, Position.Y);
		if (Direction.length() != 0)
		{
			Direction = Direction.normalize();
		}
		Vector2f velocity = Direction.scale(Speed);
		Position = Position.add(velocity.scale(delta));

		Aabb.Min.X = Position.X;
		Aabb.Min.Y = Position.Y;
		Aabb.Max.X = Position.X + Width;
		Aabb.Max.Y = Position.Y + Height;
	}

	/**
	 * Renders the entity.
	 *
	 * @param renderer Renderer for batching
	 * @param alpha    Alpha value, needed for interpolation
	 */
	public void render(Renderer renderer, float alpha)
	{
		Vector2f interpolatedPosition = PreviousPosition.lerp(Position, alpha);
		float x = interpolatedPosition.X;
		float y = interpolatedPosition.Y;
		renderer.drawTextureRegion(Texture, x, y, Tx, Ty, Width, Height, Color);
	}

	public void input() {}

	/**
	 * Checks if the paddle collided with the game border.
	 *
	 * @param gameHeight Height of the game field
	 * @param gameWidth Width of the game field
	 *
	 * @return Direction constant of the collision
	 */
	public int checkBorderCollision(int gameHeight, int gameWidth)
	{
		if (Position.Y < 0)
		{
			Position.Y = 0;
			return COLLISION_BOTTOM;
		}
		if (Position.Y > gameHeight - Height)
		{
			Position.Y = gameHeight - Height;
			return COLLISION_TOP;
		}
		if (Position.X < 0)
		{
			Position.X = 0;
			return COLLISION_LEFT;
		}
		if (Position.X > gameWidth - Width)
		{
			Position.X = gameWidth - Width;
			return COLLISION_RIGHT;
		}
		return NO_COLLISION;
	}
}