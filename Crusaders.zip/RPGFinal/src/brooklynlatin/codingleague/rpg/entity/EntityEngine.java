package brooklynlatin.codingleague.rpg.entity;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import brooklynlatin.codingleague.rpg.graphics.Renderer;
import brooklynlatin.codingleague.rpg.graphics.Texture;

public class EntityEngine
{
	private final Map<Integer, Entity> _entities = new HashMap<>();
	private int _lastAssignedId;
	
	public EntityEngine()
	{
		_lastAssignedId = 0;
	}
	
	public List<Entity> getEntities()
	{
		return _entities.values().stream().filter(ent -> !ent.isRemoved()).collect(Collectors.toList());
	}
	
	public List<Entity> getEntities(Predicate<Entity> filter)
	{
		return _entities.values().stream().filter(ent -> !ent.isRemoved()).filter(filter).collect(Collectors.toList());
	}
	
	public void update(float delta)
	{
		_entities.values().forEach(entity -> entity.update(delta));
		_entities.values().removeIf(Entity::isRemoved);
	}
	
	public void input()
	{
		_entities.values().forEach(Entity::input);
	}
	
	public void render(Renderer renderer, float alpha)
	{
		_entities.values().forEach(ent -> ent.render(renderer, alpha));
	}
	
	public void checkBorderCollisions(int gameHeight, int gameWidth)
	{
		_entities.values().forEach(ent -> ent.checkBorderCollision(gameHeight, gameWidth));
	}
	
	public <E extends Entity> E createEntity(Class<? extends E> clazz, float x, float y, Texture texture)
	{
		E newInstance = null;
		try
		{
			newInstance = clazz.getConstructor(EntityEngine.class, int.class, float.class, float.class, Texture.class).newInstance(this, _lastAssignedId++, x, y, texture);
		}
		catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e)
		{
			return null;
		}
		
		_entities.put(newInstance.getId(), newInstance);
		return newInstance;
	}
}