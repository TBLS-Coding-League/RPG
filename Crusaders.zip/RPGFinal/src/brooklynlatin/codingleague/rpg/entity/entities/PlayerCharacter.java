package brooklynlatin.codingleague.rpg.entity.entities;

import static org.lwjgl.glfw.GLFW.GLFW_KEY_A;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_D;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_DOWN;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_S;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_UP;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_W;
import static org.lwjgl.glfw.GLFW.GLFW_PRESS;
import static org.lwjgl.glfw.GLFW.glfwGetKey;

import org.lwjgl.glfw.GLFW;

import brooklynlatin.codingleague.rpg.entity.DamageableEntity;
import brooklynlatin.codingleague.rpg.entity.EntityEngine;
import brooklynlatin.codingleague.rpg.graphics.math.Vector2f;

public class PlayerCharacter extends DamageableEntity
{
	public PlayerCharacter(EntityEngine engine, int id, float x, float y, brooklynlatin.codingleague.rpg.graphics.Texture texture)
	{
		super(engine, id, "Magnus", brooklynlatin.codingleague.rpg.graphics.Color.GREEN, texture, x, y, 250f, 10, 10, 0, 0, 50);
	}

	@Override
	protected void onSpawn()
	{

	}

	@Override
	protected void updateCustom()
	{

	}

	@Override
	protected void onRemove()
	{

	}

	@Override
	public void input()
	{
		Direction = new Vector2f();
		long window = GLFW.glfwGetCurrentContext();
		if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		{
			Direction.Y = 1f;
		}
		if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		{
			Direction.X = -1f;
		}
		if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		{
			Direction.Y = -1f;
		}
		if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		{
			Direction.X = 1f;
		}
	}
}