package brooklynlatin.codingleague.rpg.entity.entities;

import java.util.List;

import brooklynlatin.codingleague.rpg.entity.DamageableEntity;
import brooklynlatin.codingleague.rpg.entity.Entity;
import brooklynlatin.codingleague.rpg.entity.EntityEngine;
import brooklynlatin.codingleague.rpg.entity.event.EntityDamageEvent.DamageCause;

public class EnemyCharacter extends DamageableEntity
{
	public EnemyCharacter(EntityEngine engine, int id, float x, float y, brooklynlatin.codingleague.rpg.graphics.Texture texture)
	{
		super(engine, id, "Villain", brooklynlatin.codingleague.rpg.graphics.Color.RED, texture, x, y, 150f, 10, 10, 0, 0, 20);
	}

	@Override
	protected void onSpawn() {}

	@Override
	protected void updateCustom()
	{
		List<Entity> players = Engine.getEntities(PlayerCharacter.class::isInstance);
		if (players.size() > 0)
		{
			PlayerCharacter character = (PlayerCharacter) players.get(0);
			
			if (character.getX() < getX())
			{
				Direction.X = -1f;
			}
			else if (character.getX() > getX())
			{
				Direction.X = 1f;
			}
			if (character.getY() < getY())
			{
				Direction.Y = -1f;
			}
			else if (character.getY() > getY())
			{
				Direction.Y = 1f;
			}
			
			if (Math.abs(character.getY() - getY()) < 3 && Math.abs(character.getX() - getX()) < 3)
			{
				character.damage(5, this, DamageCause.MELEE);
			}
		}
		else
		{
			Direction.X = 0;
			Direction.Y = 0;
		}
	}

	@Override
	protected void onRemove() {}
}