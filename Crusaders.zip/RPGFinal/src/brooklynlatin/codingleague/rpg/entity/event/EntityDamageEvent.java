package brooklynlatin.codingleague.rpg.entity.event;

import brooklynlatin.codingleague.rpg.engine.event.CancellableEvent;
import brooklynlatin.codingleague.rpg.entity.DamageableEntity;
import brooklynlatin.codingleague.rpg.entity.Entity;

public class EntityDamageEvent extends CancellableEvent
{
	private DamageableEntity _damagee;
	private Entity _damager;
	private DamageCause _cause;
	private double _damage;
	
	public EntityDamageEvent(DamageableEntity damagee, Entity damager, DamageCause cause, double damage)
	{
		_damagee = damagee;
		_damager = damager;
		_cause = cause;
		_damage = damage;
	}
	
	public DamageableEntity getDamagee()
	{
		return _damagee;
	}
	
	public Entity getDamager()
	{
		return _damager;
	}
	
	public DamageCause getCause()
	{
		return _cause;
	}
	
	public double getDamage()
	{
		return _damage;
	}
	
	public void setDamage(double damage)
	{
		_damage = damage;
	}
	
	public static enum DamageCause
	{
		MAGIC,
		FIRE,
		MELEE,
		PROJECTILE;
	}
}