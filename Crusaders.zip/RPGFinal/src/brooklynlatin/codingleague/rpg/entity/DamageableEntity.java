package brooklynlatin.codingleague.rpg.entity;

import brooklynlatin.codingleague.rpg.Damageable;
import brooklynlatin.codingleague.rpg.engine.event.EventEngine;
import brooklynlatin.codingleague.rpg.entity.event.EntityDamageEvent;
import brooklynlatin.codingleague.rpg.entity.event.EntityDamageEvent.DamageCause;
import brooklynlatin.codingleague.rpg.graphics.Color;
import brooklynlatin.codingleague.rpg.graphics.Texture;

public abstract class DamageableEntity extends Entity implements Damageable
{
	private double _health;
	private double _maxHealth;
	private final double _defaultMaxHealth;
	private long _lastHeal;
	private long _lastDamage;
	
	public DamageableEntity(EntityEngine engine, int id, String name, Color color, Texture texture, float x, float y, float speed, int width, int height, int tx, int ty, double maxHealth)
	{
		super(engine, id, name, color, texture, x, y, speed, width, height, tx, ty);
		
		_maxHealth = maxHealth;
		_defaultMaxHealth = maxHealth;
		_health = maxHealth;
		_lastHeal = System.currentTimeMillis();
	}
	
	@Override
	public void update(float delta)
	{
		if (_health <= 0)
		{
			remove();
		}
		if (_maxHealth <= 0)
		{
			_maxHealth = Math.max(0.1, _defaultMaxHealth);
		}
		if (_health < _maxHealth && System.currentTimeMillis() >= (_lastHeal + 3000))
		{
			_lastHeal = System.currentTimeMillis();
			_health = Math.min(_maxHealth, _health + 5);
		}
		super.update(delta);
	}

	@Override
	public void damage(double amount, DamageCause cause)
	{
		if (System.currentTimeMillis() < (_lastDamage + 1000))
		{
			return;
		}
		if (!EventEngine.callEvent(new EntityDamageEvent(this, null, cause, amount)).isCancelled())
		{
			_lastHeal = System.currentTimeMillis();
			_lastDamage = System.currentTimeMillis();
			_health -= amount;
		}
	}

	@Override
	public void damage(double amount, Entity source, DamageCause cause)
	{
		if (System.currentTimeMillis() < (_lastDamage + 1000))
		{
			return;
		}
		if (!EventEngine.callEvent(new EntityDamageEvent(this, source, cause, amount)).isCancelled())
		{
			_lastHeal = System.currentTimeMillis();
			_lastDamage = System.currentTimeMillis();
			_health -= amount;
		}
	}

	@Override
	public double getHealth()
	{
		return _health;
	}

	@Override
	public void setHealth(double health)
	{
		_health = health;
	}

	@Override
	public double getMaxHealth()
	{
		return _maxHealth;
	}

	@Override
	public void setMaxHealth(double health)
	{
		_maxHealth = health;
	}

	@Override
	public void resetMaxHealth()
	{
		_maxHealth = _defaultMaxHealth;
	}
}