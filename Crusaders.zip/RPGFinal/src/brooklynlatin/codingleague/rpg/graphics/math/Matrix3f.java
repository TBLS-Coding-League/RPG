package brooklynlatin.codingleague.rpg.graphics.math;

import java.nio.FloatBuffer;

/**
 * This class represents a 3x3-Matrix. GLSL equivalent to mat3.
 */
public class Matrix3f
{
	private float _m00, _m01, _m02;
	private float _m10, _m11, _m12;
	private float _m20, _m21, _m22;

	/**
	 * Creates a 3x3 identity matrix.
	 */
	public Matrix3f()
	{
		setIdentity();
	}

	/**
	 * Creates a 3x3 matrix with specified columns.
	 *
	 * @param col1 Vector with values of the first column
	 * @param col2 Vector with values of the second column
	 * @param col3 Vector with values of the third column
	 */
	public Matrix3f(Vector3f col1, Vector3f col2, Vector3f col3)
	{
		_m00 = col1.X;
		_m10 = col1.Y;
		_m20 = col1.Z;

		_m01 = col2.X;
		_m11 = col2.Y;
		_m21 = col2.Z;

		_m02 = col3.X;
		_m12 = col3.Y;
		_m22 = col3.Z;
	}

	/**
	 * Sets this matrix to the identity matrix.
	 */
	public final void setIdentity()
	{
		_m00 = 1f;
		_m11 = 1f;
		_m22 = 1f;

		_m01 = 0f;
		_m02 = 0f;
		_m10 = 0f;
		_m12 = 0f;
		_m20 = 0f;
		_m21 = 0f;
	}

	/**
	 * Adds this matrix to another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Sum of this + other
	 */
	public Matrix3f add(Matrix3f other)
	{
		Matrix3f result = new Matrix3f();

		result._m00 = _m00 + other._m00;
		result._m10 = _m10 + other._m10;
		result._m20 = _m20 + other._m20;

		result._m01 = _m01 + other._m01;
		result._m11 = _m11 + other._m11;
		result._m21 = _m21 + other._m21;

		result._m02 = _m02 + other._m02;
		result._m12 = _m12 + other._m12;
		result._m22 = _m22 + other._m22;

		return result;
	}

	/**
	 * Negates this matrix.
	 *
	 * @return Negated matrix
	 */
	public Matrix3f negate()
	{
		return multiply(-1f);
	}

	/**
	 * Subtracts this matrix from another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Difference of this - other
	 */
	public Matrix3f subtract(Matrix3f other)
	{
		return add(other.negate());
	}

	/**
	 * Multiplies this matrix with a scalar.
	 *
	 * @param scalar The scalar
	 *
	 * @return Scalar product of this * scalar
	 */
	public Matrix3f multiply(float scalar)
	{
		Matrix3f result = new Matrix3f();

		result._m00 = _m00 * scalar;
		result._m10 = _m10 * scalar;
		result._m20 = _m20 * scalar;

		result._m01 = _m01 * scalar;
		result._m11 = _m11 * scalar;
		result._m21 = _m21 * scalar;

		result._m02 = _m02 * scalar;
		result._m12 = _m12 * scalar;
		result._m22 = _m22 * scalar;

		return result;
	}

	/**
	 * Multiplies this matrix to a vector.
	 *
	 * @param vector The vector
	 *
	 * @return Vector product of this * other
	 */
	public Vector3f multiply(Vector3f vector)
	{
		float x = _m00 * vector.X + _m01 * vector.Y + _m02 * vector.Z;
		float y = _m10 * vector.X + _m11 * vector.Y + _m12 * vector.Z;
		float z = _m20 * vector.X + _m21 * vector.Y + _m22 * vector.Z;
		return new Vector3f(x, y, z);
	}

	/**
	 * Multiplies this matrix to another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Matrix product of this * other
	 */
	public Matrix3f multiply(Matrix3f other)
	{
		Matrix3f result = new Matrix3f();

		result._m00 = _m00 * other._m00 + _m01 * other._m10 + _m02 * other._m20;
		result._m10 = _m10 * other._m00 + _m11 * other._m10 + _m12 * other._m20;
		result._m20 = _m20 * other._m00 + _m21 * other._m10 + _m22 * other._m20;

		result._m01 = _m00 * other._m01 + _m01 * other._m11 + _m02 * other._m21;
		result._m11 = _m10 * other._m01 + _m11 * other._m11 + _m12 * other._m21;
		result._m21 = _m20 * other._m01 + _m21 * other._m11 + _m22 * other._m21;

		result._m02 = _m00 * other._m02 + _m01 * other._m12 + _m02 * other._m22;
		result._m12 = _m10 * other._m02 + _m11 * other._m12 + _m12 * other._m22;
		result._m22 = _m20 * other._m02 + _m21 * other._m12 + _m22 * other._m22;

		return result;
	}

	/**
	 * Transposes this matrix.
	 *
	 * @return Transposed matrix
	 */
	public Matrix3f transpose()
	{
		Matrix3f result = new Matrix3f();

		result._m00 = _m00;
		result._m10 = _m01;
		result._m20 = _m02;

		result._m01 = _m10;
		result._m11 = _m11;
		result._m21 = _m12;

		result._m02 = _m20;
		result._m12 = _m21;
		result._m22 = _m22;

		return result;
	}

	/**
	 * Stores the matrix in a given Buffer.
	 *
	 * @param buffer The buffer to store the matrix data
	 */
	public void toBuffer(FloatBuffer buffer)
	{
		buffer.put(_m00).put(_m10).put(_m20);
		buffer.put(_m01).put(_m11).put(_m21);
		buffer.put(_m02).put(_m12).put(_m22);
		buffer.flip();
	}
}