package brooklynlatin.codingleague.rpg.graphics.math;

import java.nio.FloatBuffer;

/**
 * This class represents a (x,y,z)-Vector. GLSL equivalent to vec3.
 */
public class Vector3f
{
	public float X;
	public float Y;
	public float Z;

	/**
	 * Creates a default 3-tuple vector with all values set to 0.
	 */
	public Vector3f() {
		X = 0f;
		Y = 0f;
		Z = 0f;
	}

	/**
	 * Creates a 3-tuple vector with specified values.
	 *
	 * @param x x value
	 * @param y y value
	 * @param z z value
	 */
	public Vector3f(float x, float y, float z)
	{
		X = x;
		Y = y;
		Z = z;
	}

	/**
	 * Calculates the squared length of the vector.
	 *
	 * @return Squared length of this vector
	 */
	public float lengthSquared()
	{
		return X * X + Y * Y + Z * Z;
	}

	/**
	 * Calculates the length of the vector.
	 *
	 * @return Length of this vector
	 */
	public float length()
	{
		return (float) Math.sqrt(lengthSquared());
	}

	/**
	 * Normalizes the vector.
	 *
	 * @return Normalized vector
	 */
	public Vector3f normalize()
	{
		float length = length();
		return divide(length);
	}

	/**
	 * Adds this vector to another vector.
	 *
	 * @param other The other vector
	 *
	 * @return Sum of this + other
	 */
	public Vector3f add(Vector3f other)
	{
		float x = X + other.X;
		float y = Y + other.Y;
		float z = Z + other.Z;
		return new Vector3f(x, y, z);
	}

	/**
	 * Negates this vector.
	 *
	 * @return Negated vector
	 */
	public Vector3f negate()
	{
		return scale(-1f);
	}

	/**
	 * Subtracts this vector from another vector.
	 *
	 * @param other The other vector
	 *
	 * @return Difference of this - other
	 */
	public Vector3f subtract(Vector3f other)
	{
		return add(other.negate());
	}

	/**
	 * Multiplies a vector by a scalar.
	 *
	 * @param scalar Scalar to multiply
	 *
	 * @return Scalar product of this * scalar
	 */
	public Vector3f scale(float scalar)
	{
		float x = X * scalar;
		float y = Y * scalar;
		float z = Z * scalar;
		return new Vector3f(x, y, z);
	}

	/**
	 * Divides a vector by a scalar.
	 *
	 * @param scalar Scalar to multiply
	 *
	 * @return Scalar quotient of this / scalar
	 */
	public Vector3f divide(float scalar)
	{
		return scale(1f / scalar);
	}

	/**
	 * Calculates the dot product of this vector with another vector.
	 *
	 * @param other The other vector
	 *
	 * @return Dot product of this * other
	 */
	public float dot(Vector3f other)
	{
		return X * other.X + Y * other.Y + Z * other.Z;
	}

	/**
	 * Calculates the dot product of this vector with another vector.
	 *
	 * @param other The other vector
	 *
	 * @return Cross product of this x other
	 */
	public Vector3f cross(Vector3f other)
	{
		float x = Y * other.Z - Z * other.Y;
		float y = Z * other.X - X * other.Z;
		float z = X * other.Y - Y * other.X;
		return new Vector3f(x, y, z);
	}

	/**
	 * Calculates a linear interpolation between this vector with another
	 * vector.
	 *
	 * @param other The other vector
	 * @param alpha The alpha value, must be between 0.0 and 1.0
	 *
	 * @return Linear interpolated vector
	 */
	public Vector3f lerp(Vector3f other, float alpha)
	{
		return scale(1f - alpha).add(other.scale(alpha));
	}

	/**
	 * Stores the vector in a given Buffer.
	 *
	 * @param buffer The buffer to store the vector data
	 */
	public void toBuffer(FloatBuffer buffer)
	{
		buffer.put(X).put(Y).put(Z);
		buffer.flip();
	}
}