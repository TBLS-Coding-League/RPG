package brooklynlatin.codingleague.rpg.graphics.math;

import java.nio.FloatBuffer;

/**
 * This class represents a 2x2-Matrix. GLSL equivalent to mat2.
 */
public class Matrix2f
{
	private float _m00, _m01;
	private float _m10, _m11;

	/**
	 * Create a 2x2 identity matrix.
	 */
	public Matrix2f()
	{
		setIdentity();
	}

	/**
	 * Creates a 2x2 matrix with specified columns.
	 *
	 * @param col1 Vector with values of the first column
	 * @param col2 Vector with values of the second column
	 */
	public Matrix2f(Vector2f col1, Vector2f col2)
	{
		_m00 = col1.X;
		_m10 = col1.Y;

		_m01 = col2.X;
		_m11 = col2.Y;
	}

	/**
	 * Sets this matrix to the identity matrix.
	 */
	public final void setIdentity()
	{
		_m00 = 1f;
		_m11 = 1f;

		_m01 = 0f;
		_m10 = 0f;
	}

	/**
	 * Adds this matrix to another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Sum of this + other
	 */
	public Matrix2f add(Matrix2f other)
	{
		Matrix2f result = new Matrix2f();

		result._m00 = _m00 + other._m00;
		result._m10 = _m10 + other._m10;

		result._m01 = _m01 + other._m01;
		result._m11 = _m11 + other._m11;

		return result;
	}

	/**
	 * Negates this matrix.
	 *
	 * @return Negated matrix
	 */
	public Matrix2f negate()
	{
		return multiply(-1f);
	}

	/**
	 * Subtracts this matrix from another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Difference of this - other
	 */
	public Matrix2f subtract(Matrix2f other)
	{
		return add(other.negate());
	}

	/**
	 * Multiplies this matrix with a scalar.
	 *
	 * @param scalar The scalar
	 *
	 * @return Scalar product of this * scalar
	 */
	public Matrix2f multiply(float scalar)
	{
		Matrix2f result = new Matrix2f();

		result._m00 = _m00 * scalar;
		result._m10 = _m10 * scalar;

		result._m01 = _m01 * scalar;
		result._m11 = _m11 * scalar;

		return result;
	}

	/**
	 * Multiplies this matrix to a vector.
	 *
	 * @param vector The vector
	 *
	 * @return Vector product of this * other
	 */
	public Vector2f multiply(Vector2f vector)
	{
		float x = _m00 * vector.X + _m01 * vector.Y;
		float y = _m10 * vector.X + _m11 * vector.Y;
		return new Vector2f(x, y);
	}

	/**
	 * Multiplies this matrix to another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Matrix product of this * other
	 */
	public Matrix2f multiply(Matrix2f other)
	{
		Matrix2f result = new Matrix2f();

		result._m00 = _m00 * other._m00 + _m01 * other._m10;
		result._m10 = _m10 * other._m00 + _m11 * other._m10;

		result._m01 = _m00 * other._m01 + _m01 * other._m11;
		result._m11 = _m10 * other._m01 + _m11 * other._m11;

		return result;
	}

	/**
	 * Transposes this matrix.
	 *
	 * @return Transposed matrix
	 */
	public Matrix2f transpose()
	{
		Matrix2f result = new Matrix2f();

		result._m00 = _m00;
		result._m10 = _m01;

		result._m01 = _m10;
		result._m11 = _m11;

		return result;
	}

	/**
	 * Stores the matrix in a given Buffer.
	 *
	 * @param buffer The buffer to store the matrix data
	 */
	public void toBuffer(FloatBuffer buffer)
	{
		buffer.put(_m00).put(_m10);
		buffer.put(_m01).put(_m11);
		buffer.flip();
	}
}