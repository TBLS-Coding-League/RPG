package brooklynlatin.codingleague.rpg.graphics.math;

import java.nio.FloatBuffer;

/**
 * This class represents a 4x4-Matrix. GLSL equivalent to mat4.
 */
public class Matrix4f
{
	private float _m00, _m01, _m02, _m03;
	private float _m10, _m11, _m12, _m13;
	private float _m20, _m21, _m22, _m23;
	private float _m30, _m31, _m32, _m33;

	/**
	 * Creates a 4x4 identity matrix.
	 */
	public Matrix4f()
	{
		setIdentity();
	}

	/**
	 * Creates a 4x4 matrix with specified columns.
	 *
	 * @param col1 Vector with values of the first column
	 * @param col2 Vector with values of the second column
	 * @param col3 Vector with values of the third column
	 * @param col4 Vector with values of the fourth column
	 */
	public Matrix4f(Vector4f col1, Vector4f col2, Vector4f col3, Vector4f col4)
	{
		_m00 = col1.X;
		_m10 = col1.Y;
		_m20 = col1.Z;
		_m30 = col1.W;

		_m01 = col2.Z;
		_m11 = col2.Y;
		_m21 = col2.Z;
		_m31 = col2.W;

		_m02 = col3.X;
		_m12 = col3.Y;
		_m22 = col3.Z;
		_m32 = col3.W;

		_m03 = col4.X;
		_m13 = col4.Y;
		_m23 = col4.Z;
		_m33 = col4.W;
	}

	/**
	 * Sets this matrix to the identity matrix.
	 */
	public final void setIdentity()
	{
		_m00 = 1f;
		_m11 = 1f;
		_m22 = 1f;
		_m33 = 1f;

		_m01 = 0f;
		_m02 = 0f;
		_m03 = 0f;
		_m10 = 0f;
		_m12 = 0f;
		_m13 = 0f;
		_m20 = 0f;
		_m21 = 0f;
		_m23 = 0f;
		_m30 = 0f;
		_m31 = 0f;
		_m32 = 0f;
	}

	/**
	 * Adds this matrix to another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Sum of this + other
	 */
	public Matrix4f add(Matrix4f other)
	{
		Matrix4f result = new Matrix4f();

		result._m00 = _m00 + other._m00;
		result._m10 = _m10 + other._m10;
		result._m20 = _m20 + other._m20;
		result._m30 = _m30 + other._m30;

		result._m01 = _m01 + other._m01;
		result._m11 = _m11 + other._m11;
		result._m21 = _m21 + other._m21;
		result._m31 = _m31 + other._m31;

		result._m02 = _m02 + other._m02;
		result._m12 = _m12 + other._m12;
		result._m22 = _m22 + other._m22;
		result._m32 = _m32 + other._m32;

		result._m03 = _m03 + other._m03;
		result._m13 = _m13 + other._m13;
		result._m23 = _m23 + other._m23;
		result._m33 = _m33 + other._m33;

		return result;
	}

	/**
	 * Negates this matrix.
	 *
	 * @return Negated matrix
	 */
	public Matrix4f negate()
	{
		return multiply(-1f);
	}

	/**
	 * Subtracts this matrix from another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Difference of this - other
	 */
	public Matrix4f subtract(Matrix4f other)
	{
		return add(other.negate());
	}

	/**
	 * Multiplies this matrix with a scalar.
	 *
	 * @param scalar The scalar
	 *
	 * @return Scalar product of this * scalar
	 */
	public Matrix4f multiply(float scalar)
	{
		Matrix4f result = new Matrix4f();

		result._m00 = _m00 * scalar;
		result._m10 = _m10 * scalar;
		result._m20 = _m20 * scalar;
		result._m30 = _m30 * scalar;

		result._m01 = _m01 * scalar;
		result._m11 = _m11 * scalar;
		result._m21 = _m21 * scalar;
		result._m31 = _m31 * scalar;

		result._m02 = _m02 * scalar;
		result._m12 = _m12 * scalar;
		result._m22 = _m22 * scalar;
		result._m32 = _m32 * scalar;

		result._m03 = _m03 * scalar;
		result._m13 = _m13 * scalar;
		result._m23 = _m23 * scalar;
		result._m33 = _m33 * scalar;

		return result;
	}

	/**
	 * Multiplies this matrix to a vector.
	 *
	 * @param vector The vector
	 *
	 * @return Vector product of this * other
	 */
	public Vector4f multiply(Vector4f vector)
	{
		float x = _m00 * vector.X + _m01 * vector.Y + _m02 * vector.Z + _m03 * vector.W;
		float y = _m10 * vector.X + _m11 * vector.Y + _m12 * vector.Z + _m13 * vector.W;
		float z = _m20 * vector.X + _m21 * vector.Y + _m22 * vector.Z + _m23 * vector.W;
		float w = _m30 * vector.X + _m31 * vector.Y + _m32 * vector.Z + _m33 * vector.W;
		return new Vector4f(x, y, z, w);
	}

	/**
	 * Multiplies this matrix to another matrix.
	 *
	 * @param other The other matrix
	 *
	 * @return Matrix product of this * other
	 */
	public Matrix4f multiply(Matrix4f other)
	{
		Matrix4f result = new Matrix4f();

		result._m00 = _m00 * other._m00 + _m01 * other._m10 + _m02 * other._m20 + _m03 * other._m30;
		result._m10 = _m10 * other._m00 + _m11 * other._m10 + _m12 * other._m20 + _m13 * other._m30;
		result._m20 = _m20 * other._m00 + _m21 * other._m10 + _m22 * other._m20 + _m23 * other._m30;
		result._m30 = _m30 * other._m00 + _m31 * other._m10 + _m32 * other._m20 + _m33 * other._m30;

		result._m01 = _m00 * other._m01 + _m01 * other._m11 + _m02 * other._m21 + _m03 * other._m31;
		result._m11 = _m10 * other._m01 + _m11 * other._m11 + _m12 * other._m21 + _m13 * other._m31;
		result._m21 = _m20 * other._m01 + _m21 * other._m11 + _m22 * other._m21 + _m23 * other._m31;
		result._m31 = _m30 * other._m01 + _m31 * other._m11 + _m32 * other._m21 + _m33 * other._m31;

		result._m02 = _m00 * other._m02 + _m01 * other._m12 + _m02 * other._m22 + _m03 * other._m32;
		result._m12 = _m10 * other._m02 + _m11 * other._m12 + _m12 * other._m22 + _m13 * other._m32;
		result._m22 = _m20 * other._m02 + _m21 * other._m12 + _m22 * other._m22 + _m23 * other._m32;
		result._m32 = _m30 * other._m02 + _m31 * other._m12 + _m32 * other._m22 + _m33 * other._m32;

		result._m03 = _m00 * other._m03 + _m01 * other._m13 + _m02 * other._m23 + _m03 * other._m33;
		result._m13 = _m10 * other._m03 + _m11 * other._m13 + _m12 * other._m23 + _m13 * other._m33;
		result._m23 = _m20 * other._m03 + _m21 * other._m13 + _m22 * other._m23 + _m23 * other._m33;
		result._m33 = _m30 * other._m03 + _m31 * other._m13 + _m32 * other._m23 + _m33 * other._m33;

		return result;
	}

	/**
	 * Transposes this matrix.
	 *
	 * @return Transposed matrix
	 */
	public Matrix4f transpose()
	{
		Matrix4f result = new Matrix4f();

		result._m00 = _m00;
		result._m10 = _m01;
		result._m20 = _m02;
		result._m30 = _m03;

		result._m01 = _m10;
		result._m11 = _m11;
		result._m21 = _m12;
		result._m31 = _m13;

		result._m02 = _m20;
		result._m12 = _m21;
		result._m22 = _m22;
		result._m32 = _m23;

		result._m03 = _m30;
		result._m13 = _m31;
		result._m23 = _m32;
		result._m33 = _m33;

		return result;
	}

	/**
	 * Stores the matrix in a given Buffer.
	 *
	 * @param buffer The buffer to store the matrix data
	 */
	public void toBuffer(FloatBuffer buffer)
	{
		buffer.put(_m00).put(_m10).put(_m20).put(_m30);
		buffer.put(_m01).put(_m11).put(_m21).put(_m31);
		buffer.put(_m02).put(_m12).put(_m22).put(_m32);
		buffer.put(_m03).put(_m13).put(_m23).put(_m33);
		buffer.flip();
	}

	/**
	 * Creates a orthographic projection matrix. Similar to
	 * <code>glOrtho(left, right, bottom, top, near, far)</code>.
	 *
	 * @param left   Coordinate for the left vertical clipping pane
	 * @param right  Coordinate for the right vertical clipping pane
	 * @param bottom Coordinate for the bottom horizontal clipping pane
	 * @param top    Coordinate for the bottom horizontal clipping pane
	 * @param near   Coordinate for the near depth clipping pane
	 * @param far    Coordinate for the far depth clipping pane
	 *
	 * @return Orthographic matrix
	 */
	public static Matrix4f orthographic(float left, float right, float bottom, float top, float near, float far)
	{
		Matrix4f ortho = new Matrix4f();

		float tx = -(right + left) / (right - left);
		float ty = -(top + bottom) / (top - bottom);
		float tz = -(far + near) / (far - near);

		ortho._m00 = 2f / (right - left);
		ortho._m11 = 2f / (top - bottom);
		ortho._m22 = -2f / (far - near);
		ortho._m03 = tx;
		ortho._m13 = ty;
		ortho._m23 = tz;

		return ortho;
	}

	/**
	 * Creates a perspective projection matrix. Similar to
	 * <code>glFrustum(left, right, bottom, top, near, far)</code>.
	 *
	 * @param left   Coordinate for the left vertical clipping pane
	 * @param right  Coordinate for the right vertical clipping pane
	 * @param bottom Coordinate for the bottom horizontal clipping pane
	 * @param top    Coordinate for the bottom horizontal clipping pane
	 * @param near   Coordinate for the near depth clipping pane, must be
	 *               positive
	 * @param far    Coordinate for the far depth clipping pane, must be
	 *               positive
	 *
	 * @return Perspective matrix
	 */
	public static Matrix4f frustum(float left, float right, float bottom, float top, float near, float far)
	{
		Matrix4f frustum = new Matrix4f();

		float a = (right + left) / (right - left);
		float b = (top + bottom) / (top - bottom);
		float c = -(far + near) / (far - near);
		float d = -(2f * far * near) / (far - near);

		frustum._m00 = (2f * near) / (right - left);
		frustum._m11 = (2f * near) / (top - bottom);
		frustum._m02 = a;
		frustum._m12 = b;
		frustum._m22 = c;
		frustum._m32 = -1f;
		frustum._m23 = d;
		frustum._m33 = 0f;

		return frustum;
	}

	/**
	 * Creates a perspective projection matrix. Similar to
	 * <code>gluPerspective(fovy, aspec, zNear, zFar)</code>.
	 *
	 * @param fovy   Field of view angle in degrees
	 * @param aspect The aspect ratio is the ratio of width to height
	 * @param near   Distance from the viewer to the near clipping plane, must
	 *               be positive
	 * @param far    Distance from the viewer to the far clipping plane, must be
	 *               positive
	 *
	 * @return Perspective matrix
	 */
	public static Matrix4f perspective(float fovy, float aspect, float near, float far)
	{
		Matrix4f perspective = new Matrix4f();

		float f = (float) (1f / Math.tan(Math.toRadians(fovy) / 2f));

		perspective._m00 = f / aspect;
		perspective._m11 = f;
		perspective._m22 = (far + near) / (near - far);
		perspective._m32 = -1f;
		perspective._m23 = (2f * far * near) / (near - far);
		perspective._m33 = 0f;

		return perspective;
	}

	/**
	 * Creates a translation matrix. Similar to
	 * <code>glTranslate(x, y, z)</code>.
	 *
	 * @param x x coordinate of translation vector
	 * @param y y coordinate of translation vector
	 * @param z z coordinate of translation vector
	 *
	 * @return Translation matrix
	 */
	public static Matrix4f translate(float x, float y, float z)
	{
		Matrix4f translation = new Matrix4f();

		translation._m03 = x;
		translation._m13 = y;
		translation._m23 = z;

		return translation;
	}

	/**
	 * Creates a rotation matrix. Similar to
	 * <code>glRotate(angle, x, y, z)</code>.
	 *
	 * @param angle Angle of rotation in degrees
	 * @param x     x coordinate of the rotation vector
	 * @param y     y coordinate of the rotation vector
	 * @param z     z coordinate of the rotation vector
	 *
	 * @return Rotation matrix
	 */
	public static Matrix4f rotate(float angle, float x, float y, float z)
	{
		Matrix4f rotation = new Matrix4f();

		float c = (float) Math.cos(Math.toRadians(angle));
		float s = (float) Math.sin(Math.toRadians(angle));
		Vector3f vec = new Vector3f(x, y, z);
		if (vec.length() != 1f) {
			vec = vec.normalize();
			x = vec.X;
			y = vec.Y;
			z = vec.Z;
		}

		rotation._m00 = x * x * (1f - c) + c;
		rotation._m10 = y * x * (1f - c) + z * s;
		rotation._m20 = x * z * (1f - c) - y * s;
		rotation._m01 = x * y * (1f - c) - z * s;
		rotation._m11 = y * y * (1f - c) + c;
		rotation._m21 = y * z * (1f - c) + x * s;
		rotation._m02 = x * z * (1f - c) + y * s;
		rotation._m12 = y * z * (1f - c) - x * s;
		rotation._m22 = z * z * (1f - c) + c;

		return rotation;
	}

	/**
	 * Creates a scaling matrix. Similar to <code>glScale(x, y, z)</code>.
	 *
	 * @param x Scale factor along the x coordinate
	 * @param y Scale factor along the y coordinate
	 * @param z Scale factor along the z coordinate
	 *
	 * @return Scaling matrix
	 */
	public static Matrix4f scale(float x, float y, float z)
	{
		Matrix4f scaling = new Matrix4f();

		scaling._m00 = x;
		scaling._m11 = y;
		scaling._m22 = z;

		return scaling;
	}
}