package brooklynlatin.codingleague.rpg.graphics.math;

import java.nio.FloatBuffer;

/**
 * This class represents a (x,y)-Vector. GLSL equivalent to vec2.
 */
public class Vector2f
{
	public float X;
	public float Y;

	/**
	 * Creates a default 2-tuple vector with all values set to 0.
	 */
	public Vector2f()
	{
		X = 0f;
		Y = 0f;
	}

	/**
	 * Creates a 2-tuple vector with specified values.
	 *
	 * @param x x value
	 * @param y y value
	 */
	public Vector2f(float x, float y)
	{
		X = x;
		Y = y;
	}

	/**
	 * Calculates the squared length of the vector.
	 *
	 * @return Squared length of this vector
	 */
	public float lengthSquared()
	{
		return X * X + Y * Y;
	}

	/**
	 * Calculates the length of the vector.
	 *
	 * @return Length of this vector
	 */
	public float length()
	{
		return (float) Math.sqrt(lengthSquared());
	}

	/**
	 * Normalizes the vector.
	 *
	 * @return Normalized vector
	 */
	public Vector2f normalize()
	{
		float length = length();
		return divide(length);
	}

	/**
	 * Adds this vector to another vector.
	 *
	 * @param other The other vector
	 *
	 * @return Sum of this + other
	 */
	public Vector2f add(Vector2f other)
	{
		float x = X + other.X;
		float y = Y + other.Y;
		return new Vector2f(x, y);
	}

	/**
	 * Negates this vector.
	 *
	 * @return Negated vector
	 */
	public Vector2f negate()
	{
		return scale(-1f);
	}

	/**
	 * Subtracts this vector from another vector.
	 *
	 * @param other The other vector
	 *
	 * @return Difference of this - other
	 */
	public Vector2f subtract(Vector2f other)
	{
		return add(other.negate());
	}

	/**
	 * Multiplies a vector by a scalar.
	 *
	 * @param scalar Scalar to multiply
	 *
	 * @return Scalar product of this * scalar
	 */
	public Vector2f scale(float scalar)
	{
		float x = X * scalar;
		float y = Y * scalar;
		return new Vector2f(x, y);
	}

	/**
	 * Divides a vector by a scalar.
	 *
	 * @param scalar Scalar to multiply
	 *
	 * @return Scalar quotient of this / scalar
	 */
	public Vector2f divide(float scalar)
	{
		return scale(1f / scalar);
	}

	/**
	 * Calculates the dot product of this vector with another vector.
	 *
	 * @param other The other vector
	 *
	 * @return Dot product of this * other
	 */
	public float dot(Vector2f other)
	{
		return X * other.X + Y * other.Y;
	}

	/**
	 * Calculates a linear interpolation between this vector with another
	 * vector.
	 *
	 * @param other The other vector
	 * @param alpha The alpha value, must be between 0.0 and 1.0
	 *
	 * @return Linear interpolated vector
	 */
	public Vector2f lerp(Vector2f other, float alpha)
	{
		return scale(1f - alpha).add(other.scale(alpha));
	}

	/**
	 * Stores the vector in a given Buffer.
	 *
	 * @param buffer The buffer to store the vector data
	 */
	public void toBuffer(FloatBuffer buffer)
	{
		buffer.put(X).put(Y);
		buffer.flip();
	}
}