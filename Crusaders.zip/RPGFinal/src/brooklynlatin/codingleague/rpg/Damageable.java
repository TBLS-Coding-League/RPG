package brooklynlatin.codingleague.rpg;

import brooklynlatin.codingleague.rpg.entity.Entity;
import brooklynlatin.codingleague.rpg.entity.event.EntityDamageEvent.DamageCause;

public interface Damageable
{
    /**
     * Deals the given amount of damage.
     *
     * @param amount Amount of damage to deal
     * @param cause Cause of damage
     */
    void damage(double amount, DamageCause cause);

    /**
     * Deals the given amount of damage, from a specified
     * entity.
     *
     * @param amount Amount of damage to deal
     * @param source Entity which to attribute this damage from
     * @param cause Cause of damage
     */
    void damage(double amount, Entity source, DamageCause cause);

    /**
     * Gets the health from 0 to {@link #getMaxHealth()}, where 0 is dead.
     *
     * @return Health represented from 0 to max
     */
    double getHealth();

    /**
     * Sets the health from 0 to {@link #getMaxHealth()}, where 0 is
     * dead.
     *
     * @param health New health represented from 0 to max
     */
    void setHealth(double health);

    /**
     * Gets the maximum health.
     *
     * @return Maximum health
     */
    double getMaxHealth();

    /**
     * Sets the maximum health.
     * <p>
     * If the health is above the value provided it will be set
     * to that value.
     *
     * @param health amount of health to set the maximum to
     */
    void setMaxHealth(double health);

    /**
     * Resets the max health to the original amount.
     */
    void resetMaxHealth();
}