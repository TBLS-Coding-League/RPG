package brooklynlatin.codingleague.rpg.entity;

import brooklynlatin.codingleague.rpg.util.XYPosition;
import brooklynlatin.codingleague.rpg.util.XYVector;

public abstract class Entity
{
	private final int _id;
	private String _name;
	private XYPosition _position;
	private XYVector _vector;
	private boolean _removing;
	private boolean _removed;
	
	public Entity(int id, String name, XYPosition position)
	{
		_id = id;
		_name = name;
		_position = position;
		_vector = XYVector.getZero();
		onSpawn();
	}
	
	protected abstract void onSpawn();
	protected abstract void updateCustom();
	protected abstract void onRemove();
	
	public int getId()
	{
		return _id;
	}
	
	public String getName()
	{
		return _name;
	}
	
	public XYPosition getPosition()
	{
		return _position;
	}
	
	public XYVector getVelocity()
	{
		return _vector;
	}
	
	public boolean isRemoved()
	{
		return _removed;
	}
	
	public void teleport(XYPosition position)
	{
		_position = position;
	}
	
	public void setVelocity(XYVector vector)
	{
		_vector = vector;
	}
	
	public void remove()
	{
		if (_removed)
		{
			return;
		}
		_removing = true;
	}
	
	protected void update()
	{
		if (_removing)
		{
			_removed = true;
			onRemove();
			return;
		}
		updateCustom();
	}
}