package brooklynlatin.codingleague.rpg.entity;

import java.awt.image.BufferedImage;

import brooklynlatin.codingleague.rpg.Drawable;
import brooklynlatin.codingleague.rpg.util.ImageUtil;
import brooklynlatin.codingleague.rpg.util.XYPosition;

public abstract class DrawableEntity extends Entity implements Drawable
{
	private BufferedImage _image;
	
	public DrawableEntity(int id, String name, XYPosition position, String imageName)
	{
		super(id, name, position);
		
		_image = ImageUtil.loadImage(imageName);
	}
	
	public void draw()
	{
		
	}
	
	@Override
	public void update()
	{
		super.update();
		if (!isRemoved())
		{
			draw();
		}
	}
}