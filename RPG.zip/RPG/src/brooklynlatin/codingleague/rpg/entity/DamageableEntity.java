package brooklynlatin.codingleague.rpg.entity;

import brooklynlatin.codingleague.rpg.Damageable;
import brooklynlatin.codingleague.rpg.util.XYPosition;

public abstract class DamageableEntity extends Entity implements Damageable
{
	private double _health;
	private double _maxHealth;
	private final double _defaultMaxHealth;
	
	public DamageableEntity(int id, String name, XYPosition position, double maxHealth)
	{
		super(id, name, position);
		
		_maxHealth = maxHealth;
		_defaultMaxHealth = maxHealth;
		_health = maxHealth;
	}
	
	@Override
	public void update()
	{
		if (_health <= 0)
		{
			remove();
		}
		if (_maxHealth <= 0)
		{
			_maxHealth = Math.max(0.1, _defaultMaxHealth);
		}
		if (_health < _maxHealth)
		{
			_health = _maxHealth;
		}
		super.update();
	}

	@Override
	public void damage(double amount)
	{
		_health -= amount;
	}

	@Override
	public void damage(double amount, Entity source)
	{
		_health -= amount;
	}

	@Override
	public double getHealth()
	{
		return _health;
	}

	@Override
	public void setHealth(double health)
	{
		_health = health;
	}

	@Override
	public double getMaxHealth()
	{
		return _maxHealth;
	}

	@Override
	public void setMaxHealth(double health)
	{
		_maxHealth = health;
	}

	@Override
	public void resetMaxHealth()
	{
		_maxHealth = _defaultMaxHealth;
	}
}