package brooklynlatin.codingleague.rpg.entity;

import brooklynlatin.codingleague.rpg.util.XYPosition;

public class ExampleEntity extends Entity
{
	public ExampleEntity(int id, XYPosition position)
	{
		super(id, "Example Entity", position);
	}

	@Override
	protected void onSpawn() {}

	@Override
	protected void updateCustom() {}

	@Override
	protected void onRemove() {}
}