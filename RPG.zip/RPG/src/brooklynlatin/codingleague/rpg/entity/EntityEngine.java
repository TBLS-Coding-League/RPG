package brooklynlatin.codingleague.rpg.entity;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import brooklynlatin.codingleague.rpg.util.XYPosition;

public class EntityEngine
{
	private final Map<Integer, Entity> _entities = new HashMap<>();
	private int _lastAssignedId;
	
	public static void main(String[] args)
	{
		new EntityEngine();
	}
	
	public EntityEngine()
	{
		_lastAssignedId = 0;
		for (int i = 0; i < 50; i++)
		{
			createEntity(ExampleEntity.class, XYPosition.getOrigin());
		}
		System.out.println(_entities.size());
		System.out.println(_lastAssignedId);
		for (Entity ent : _entities.values())
		{
			System.out.println(ent.getId() + " - " + ent.getName());
		}
		System.out.println("Handling Entity Logic");
		while (true)
		{
			for (Entity ent : _entities.values())
			{
				ent.update();
			}
		}
	}
	
	public <E extends Entity> E createEntity(Class<? extends E> clazz, XYPosition position)
	{
		E newInstance = null;
		try
		{
			newInstance = clazz.getConstructor(int.class, XYPosition.class).newInstance(_lastAssignedId++, position);
		}
		catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e)
		{
			return null;
		}
		
		_entities.put(newInstance.getId(), newInstance);
		return newInstance;
	}
}