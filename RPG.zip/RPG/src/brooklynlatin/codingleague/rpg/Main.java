package brooklynlatin.codingleague.rpg;

public class Main
{
	private static Main _instance;
	
	public static void main(String[] args)
	{
		_instance = new Main();
	}
	
	public static Main getInstance()
	{
		if (_instance == null)
		{
			return _instance = new Main();
		}
		
		return _instance;
	}
}