package brooklynlatin.codingleague.rpg.util;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import brooklynlatin.codingleague.rpg.Main;

public class ImageUtil
{
	public static BufferedImage loadImage(String fileName)
	{
		BufferedImage buff = null;
		try
		{
			buff = ImageIO.read(Main.getInstance().getClass().getResourceAsStream("/resources/" + fileName));
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return null;
		}
		return buff;
	}
}