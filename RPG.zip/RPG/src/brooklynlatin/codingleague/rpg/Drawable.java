package brooklynlatin.codingleague.rpg;

public interface Drawable
{
	public abstract void draw();
}