package brooklynlatin.codingleague.rpg.engine;

import brooklynlatin.codingleague.rpg.engine.GameEvent.EventPriority;

public abstract class EventListener <T extends GameEvent>
{
	private Class<T> _clazz;
	
	public EventListener(Class<T> eventClass)
	{
		_clazz = eventClass;
	}
	
	public abstract EventPriority getPriority();
	
	public abstract void handleEvent(T event);
	
	public Class<T> getEventClass()
	{
		return _clazz;
	}
}