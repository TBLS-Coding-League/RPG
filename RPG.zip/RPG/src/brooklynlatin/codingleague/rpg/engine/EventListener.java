package brooklynlatin.codingleague.rpg.engine;

public abstract class EventListener <T extends GameEvent>
{
	public abstract void handleEvent(T event);
}