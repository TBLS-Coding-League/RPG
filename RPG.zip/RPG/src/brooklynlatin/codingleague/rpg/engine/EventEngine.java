package brooklynlatin.codingleague.rpg.engine;

import java.util.List;
import java.util.Map;

public class EventEngine
{
	public static Map<Class<? extends GameEvent>, List<EventListener<?>>> _listeners;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T extends GameEvent> T callEvent(T event)
	{
		for (EventListener listener : _listeners.get(event.getClass()))
		{
			listener.handleEvent(event);
		}
		return event;
	}
	
	public void registerListener(EventListener listener)
	{
		
	}
}