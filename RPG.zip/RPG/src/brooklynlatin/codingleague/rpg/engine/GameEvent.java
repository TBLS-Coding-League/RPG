package brooklynlatin.codingleague.rpg.engine;

public abstract class GameEvent
{
	public static enum EventPriority
	{
		HIGHEST,
		HIGH,
		NORMAL,
		LOW,
		LOWEST;
	}
}