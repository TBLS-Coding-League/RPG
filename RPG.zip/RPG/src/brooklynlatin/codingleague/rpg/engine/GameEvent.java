package brooklynlatin.codingleague.rpg.engine;

public abstract class GameEvent
{

}